test_that( "ChisqInd correct output", {
  test <- ChisqInd(matrix(c(10, 20, 15, 25), nrow = 2, byrow = TRUE))
  expect_equal(test$p, 0.71881636)

}

)
